const WALLETS_API_URL = "https://fr-wallet-api.id-chain.net";
const NFT_PUB_API_URL = "https://fr-nft-pub-api.id-chain.net";
const NFT_ROOT_URL = "https://filerights.id-chain.net/nft";
const UNLIMITED = 9999999; //unlimited nft tokens for profile in smartcontract


const nft_contract_abi = [{"inputs":[],"stateMutability":"nonpayable","type":"constructor"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"_owner","type":"address"},{"indexed":true,"internalType":"address","name":"_approved","type":"address"},{"indexed":true,"internalType":"uint256","name":"_tokenId","type":"uint256"}],"name":"Approval","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"_owner","type":"address"},{"indexed":true,"internalType":"address","name":"_operator","type":"address"},{"indexed":false,"internalType":"bool","name":"_approved","type":"bool"}],"name":"ApprovalForAll","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"previousOwner","type":"address"},{"indexed":true,"internalType":"address","name":"newOwner","type":"address"}],"name":"OwnershipTransferred","type":"event"},{"anonymous":false,"inputs":[{"indexed":true,"internalType":"address","name":"_from","type":"address"},{"indexed":true,"internalType":"address","name":"_to","type":"address"},{"indexed":true,"internalType":"uint256","name":"_tokenId","type":"uint256"}],"name":"Transfer","type":"event"},{"inputs":[],"name":"CANNOT_TRANSFER_TO_ZERO_ADDRESS","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"NOT_CURRENT_OWNER","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_approved","type":"address"},{"internalType":"uint256","name":"_tokenId","type":"uint256"}],"name":"approve","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_owner","type":"address"}],"name":"balanceOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_tokenId","type":"uint256"}],"name":"burn","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_tokenId","type":"uint256"}],"name":"getApproved","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getContractBalance","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getMintPrice","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_owner","type":"address"},{"internalType":"address","name":"_operator","type":"address"}],"name":"isApprovedForAll","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_tokenId","type":"uint256"}],"name":"isFreeTokenId","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_to","type":"address"},{"internalType":"string","name":"file_hash","type":"string"}],"name":"mint","outputs":[{"internalType":"uint256","name":"t_id","type":"uint256"}],"stateMutability":"payable","type":"function"},{"inputs":[],"name":"name","outputs":[{"internalType":"string","name":"_name","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"owner","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_tokenId","type":"uint256"}],"name":"ownerOf","outputs":[{"internalType":"address","name":"_owner","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_from","type":"address"},{"internalType":"address","name":"_to","type":"address"},{"internalType":"uint256","name":"_tokenId","type":"uint256"}],"name":"safeTransferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_from","type":"address"},{"internalType":"address","name":"_to","type":"address"},{"internalType":"uint256","name":"_tokenId","type":"uint256"},{"internalType":"bytes","name":"_data","type":"bytes"}],"name":"safeTransferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_operator","type":"address"},{"internalType":"bool","name":"_approved","type":"bool"}],"name":"setApprovalForAll","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"new_price","type":"uint256"}],"name":"setMintPrice","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"new_name","type":"string"}],"name":"setNFTName","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"string","name":"new_symbol","type":"string"}],"name":"setNFTSymbol","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bytes4","name":"_interfaceID","type":"bytes4"}],"name":"supportsInterface","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"symbol","outputs":[{"internalType":"string","name":"_symbol","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_index","type":"uint256"}],"name":"tokenByIndex","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_tokenId","type":"uint256"}],"name":"tokenHashById","outputs":[{"internalType":"string","name":"hash","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"string","name":"hash","type":"string"}],"name":"tokenIdByHash","outputs":[{"internalType":"uint256","name":"tokenId","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_owner","type":"address"},{"internalType":"uint256","name":"_index","type":"uint256"}],"name":"tokenOfOwnerByIndex","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"string","name":"hash","type":"string"}],"name":"tokenOwnerByHash","outputs":[{"internalType":"address","name":"tokenOwner","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"_tokenId","type":"uint256"}],"name":"tokenURI","outputs":[{"internalType":"string","name":"","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"totalSupply","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_from","type":"address"},{"internalType":"address","name":"_to","type":"address"},{"internalType":"uint256","name":"_tokenId","type":"uint256"}],"name":"transferFrom","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_newOwner","type":"address"}],"name":"transferOwnership","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"addresspayable","name":"sendTo","type":"address"},{"internalType":"uint256","name":"amount","type":"uint256"}],"name":"withdraw","outputs":[],"stateMutability":"nonpayable","type":"function"}];
const nft_contract_address = '0xfef4d47d6bd8f84728db8416332526242e79b120';

const chains = new Array();
	  chains['0x1'] = "mainnet";
	  chains['1'] = "mainnet"; //for opera
	  chains['0x3'] = "ropsten";
	  chains['0x4'] = "rinkeby";
	  chains['0x5'] = "goerli";
	  chains["0x2a"] = "kovan";

const infura_urls = new Array();
	  infura_urls['mainnet'] = 'https://mainnet.infura.io/v3/2e23ced13c414a9ea6f181b8dc58fe37'
	  infura_urls['kovan'] = 'https://kovan.infura.io/v3/2e23ced13c414a9ea6f181b8dc58fe37';

const current_network = 'kovan';

const ADJ_CONSTANT = 1000000000000000000; //10^18

const BAD_PROFILE_ID = 9999999; //as in smartcontract

//window.scrollReveal = new scrollReveal();	

// *** wallet connect variables

const Web3Modal = window.Web3Modal.default;
const WalletConnectProvider = window.WalletConnectProvider.default;
const evmChains = window.evmChains;


const providerOptions = {
		walletconnect: {
		      package: WalletConnectProvider,
		      options: {
		        
		        infuraId: "64aa7b9fd66b4202985f5d758789331e",
		      }
		    }
};

// *** end of wallet connect variables



const walletButton = document.getElementById("enableEthereumButton");
const forwardedOrigin = "https://filerights.id-chain.net";
//const myDecipher = decipher('dfastqw34t34t4t34');


const isMetaMaskInstalled = () => {
	if (typeof window.ethereum != undefined){
		return Boolean(window.ethereum && window.ethereum.isMetaMask);
	}
}



function linkToHash(link){
	let ind = link.indexOf('?');
	if (ind == -1) return ''
	else return link.slice(ind+6); //'?hash='
}

function processUrl(){
	let hash = linkToHash(window.location.href);
	if (hash) showNFTPage(hash);
}

async function showNFTPage(hash){
	let owner = await window.nft_smartcontract_reader.methods.tokenOwnerByHash(hash).call();
	let t_id =  await window.nft_smartcontract_reader.methods.tokenIdByHash(hash).call();

	const data = await getData(NFT_ROOT_URL+'/'+hash+'.json');

	let html = '<div style="margin-top: 2vh;">Owner: '+owner+'</div>';
	html += '<div style="margin-top: 2vh;">Token ID: '+t_id+'</div>';
	html += '<div style="margin-top: 2vh;">Title: '+data.name+'</div>';
	html += '<div style="margin-top: 2vh;">Description: '+data.description+'</div>';


	document.getElementById('nft_full_info_content').innerHTML = html;
	

	document.getElementById('nft_full_info').style.display = "block";
}

window.addEventListener('DOMContentLoaded', async () => {
	
	//in any case;
	await initWeb3jsReader();
	await initNFTPubContractReader();
	processUrl();

	

	

	if (isMetaMaskInstalled()){
			
			window.ethereum.autoRefreshOnNetworkChange = false;
			getAccount();

		 	window.ethereum.on('accountsChanged', function(accounts){
		  		getAccount();
		  	});

		  	window.ethereum.on('chainChanged', (chainId) => {
		 		getAccount();
			});

			

	} else {

	  
		walletButton.style.display="block";

		initWeb3Modal();
		

	  	walletButton.addEventListener("click", toggleWeb3Connect);

	}

	
});

function initWeb3Modal(){

		web3Modal = new Web3Modal({
		    cacheProvider: false, // optional
		    providerOptions, // required
		    disableInjectedProvider: true, // optional. For MetaMask / Brave / Opera.
			
		});
}

function setupList(list,introText){
	let defaultOption = document.createElement('option');
  	defaultOption.text = introText;

  	list.add(defaultOption);
  	list.selectedIndex = 0;
}

function fillList(url,list_elem,field_name, val_field_name = null, complex_val = false, callback = null){

	let myHeaders = new Headers();
	myHeaders.append("Content-Type", "application/json");
	myHeaders.append("servicekeyauth", window.service_key);

	

	let requestOptions = {
	  method: 'GET',
	  headers: myHeaders,
	  redirect: 'follow'
	};

	fetch(url,requestOptions)
  		.then(
  			function(response) {
  				if (response.status !== 200){
  					
  					return;
  				}

  				response.json().then(function(data){
  					let option;

  					for (let i=0; i < data.length; i++){
  						option = document.createElement('option');
  						
  						option.text = data[i][field_name];
  						if (!val_field_name && !complex_val){
  							option.value = option.text;
  						} else if (!complex_val && val_field_name){
  							option.value = data[i][val_field_name];
  						} else if (complex_val){ //complex_val
  							option.value =  JSON.stringify(data[i]);
  						} else { 
  							option.value = option.text;
  						}	
  						list_elem.add(option);
  					}
  					
  					list_elem.style.display = "block";
					if (callback) callback();
  				});

  			}
  		).catch(function(err){
  			
  		});
}


async function getAccount(){
	
	try{
	
		window.accounts = await ethereum.request({method:'eth_requestAccounts'});
		window.account = accounts[0];
		window.chainId = window.ethereum.chainId;
		if (window.chainId == undefined) window.chainId = '0x1';
	
			
		safeSetValueById('to_wallet', window.account);
		
		safeSetValueBySelector( '.current-wallet', window.account);
		

		

        window.web3js =  await new Web3(window.ethereum);
		window.web3 = window.web3js;
		window.BN = web3js.utils.BN;

		
		await initNFTPubContract();
		await initNFTPubContractReader();
		
		

		

	} catch (error){
		errorMsg('please connect wallet');
	}
	
}

async function getAccountWalletConnect(){

	try{
	////
		window.web3js =  await new Web3(window.provider);
		window.web3 = window.web3js;


		// Get connected chain id from Ethereum node
		const chainId = await window.web3js.eth.getChainId();

		//do not rely on automatic..
		
		if (window.chainId == undefined) window.chainId = '0x1';


		// Load chain information over an HTTP API
		const chainData = evmChains.getChain(chainId);
 

  		// Get list of accounts of the connected wallet
  		window.accounts = await web3js.eth.getAccounts();
	
		window.account = accounts[0];
	
		//safeSetInnerHTMLBySelector('.showAccount','['+chains[window.ethereum.chainId]+'] '+account);
			
		safeSetValueById('to_wallet', window.account);
		
		safeSetValueBySelector( '.current-wallet', window.account);

		//for MM-based code to work without changes for smart contract interactions
		window.ethereum = window.provider; 

	
		
		await window.provider.enable();
		
        
		window.BN = web3js.utils.BN;

		
		await initNFTPubContract();

		
	

		
		

	} catch (error){
		errorMsg('please connect wallet');
	}
	
}
	






function temporaryDisableCurrentButton(){
	let elem = event.srcElement;
	elem.disabled = true;
	setTimeout(() => { elem.disabled  = false;}, 10000);
}


async function mintNFT(hash){

	let wei_price = await window.nft_smartcontract.methods.getMintPrice().call();
	
	window.nft_smartcontract.methods.mint(window.account, hash).send({from: window.account, value: wei_price}, function(error, txnHash) {
	        if (error) throw error;
	        output_transaction(txnHash)
	        //save nft + generate img with QR code -> link to NFT json
	        saveNftProfile({ name: document.getElementById('name').value,
									 description: document.getElementById('desc').value,	
									 hash: hash
									}, (res) => console.log(res));
			
	    })
	    .on('confirmation', function(confirmationNumber, receipt){
				if (confirmationNumber == 5){
					resetMsg();
					
				} 


		})
		.catch(error => 	{
				errorMsg('smartcontract communication error');
			
		});   

	
}


async function checkUniq(hash, callback){
		

	let tokenId = await window.nft_smartcontract.methods.tokenIdByHash(hash).call();
	
	if (callback) callback(tokenId);
	
}


function uploadFile(callback){

	     
	  let myHeaders = new Headers();
	  //myHeaders.append("Content-Type", "application/json");
	  const formData = new FormData();
	  const fileField = document.getElementById('userfile');

	  formData.append('name', document.getElementById('name').value);
	  formData.append('desc', document.getElementById('desc').value);
	  formData.append('userfile', fileField.files[0]);
	  

	  let requestOptions = {
	    method: 'POST',
	    headers: myHeaders,
	    body: formData
	  };

	  fetch('https://fr-upl-api.id-chain.net/upload', requestOptions)
	    .then(response => { 
	                if (response.status !== 200){
	                  throw new Error(response.status);
	                } else {
	                  return response.clone().json();
	                }
	                
	              })
	    .then(respJson => {
	                if (respJson.type == "success"){
	                    callback( respJson);   
	                } else {
	                    callback( respJson.message );                
	                }
	                

	               
	              })
	    .catch(error =>   {
	                callback( "connection to API error" ); 
	                
	              });     
}


function saveNftProfile(nft_profile,callback){

	     
	  let myHeaders = new Headers();
	  myHeaders.append("Content-Type", "application/json");
	  let raw = JSON.stringify(nft_profile);	
	  

	  let requestOptions = {
	    method: 'POST',
	    headers: myHeaders,
	    body: raw
	  };

	  fetch('https://fr-upl-api.id-chain.net/save_nft_profile', requestOptions)
	    .then(response => { 
	                if (response.status !== 200){
	                  throw new Error(response.status);
	                } else {
	                  return response.clone().json();
	                }
	                
	              })
	    .then(respJson => {
	                if (respJson.type == "success"){
	                    callback( respJson);   
	                } else {
	                    callback( respJson.message );                
	                }
	                

	               
	              })
	    .catch(error =>   {
	                callback( "connection to API error" ); 
	                
	              });     
}



function output_transaction(txnHash, color = 'white', element_id = 'info_pane', elem_to_hide = null){
	let el = document.getElementById(element_id);
	if (el) {
		let ch ='';
		if (window.chainId != '0x1' && window.chainId != '1') ch = chains[window.ethereum.chainId]+'.';

	    el.innerHTML = 
    	'<span style="color: '+color+'";"><a style="color: ' +color+ ';" target="_blank" href="https://'+ch+'etherscan.io/tx/'+txnHash+'">last transaction: '+txnHash+'</a></span>';
		el.style.display = "block";
	}
	if (elem_to_hide) document.getElementById(elem_to_hide).style.display = "none";
}


function safeSetValueById(id, value){
	let el = document.getElementById(id);
	if (el) {
		el.value = value;
		if (value == '' ) el.style.display = "none";
		else el.style.display = "block";
	}
}


function safeSetInnerHTMLById(id, value){
	let el = document.getElementById(id);
	if (el){
		 el.innerHTML = value;
		 if (value == '' ) el.style.display = "none"
		 else el.style.display = "block";
	}
}

function safeSetValueBySelector(selector, value){
	
	let els = document.querySelectorAll(selector);
	if (els){
		els.forEach(function(item) {
		  item.value = value;
		});
	}
}

function safeHideBySelector(selector){
	
	let els = document.querySelectorAll(selector);
	if (els){
		els.forEach(function(item) {
		  item.style.display = "none";
		});
	}
}

function safeShowBySelector(selector){
	
	let els = document.querySelectorAll(selector);
	if (els){
		els.forEach(function(item) {
		  item.style.display = "block";
		});
	}
}

function safeSetInnerHTMLBySelector(selector, value){
	let el = document.querySelector(selector);
	if (el){
		 el.innerHTML = value;
		 if (value == '' ) el.style.display = "none"
		 else el.style.display = "block";
	}
}

function assetNFTUrlByName(asset_name){
	return NFT_ROOT_URL+'/'+asset_name+'.json';
}

function setupList(list,introText){
	let defaultOption = document.createElement('option');
  	defaultOption.text = introText;

  	list.add(defaultOption);
  	list.selectedIndex = 0;
}

function assetsListOnChange(){
	let assets_list = document.getElementById('assets_list');
	if (assets_list.selectedIndex > 0){
		let val = JSON.parse(assets_list.value);

		
		document.getElementById('my_assets_asset_img').src = val.asset_img_url;
		
		document.getElementById('my_assets_transfer_panel').style.display = "block";

		document.getElementById('my_assets_name').value = val.asset_name;
		document.getElementById('my_assets_description').value = val.asset_description;
		document.getElementById('my_assets_name_div').style.display = "block";
		document.getElementById('my_assets_description_div').style.display = "block";


	} else {
		document.getElementById('my_assets_transfer_panel').style.display = "none";
		document.getElementById('my_assets_name_div').style.display = "none";
		document.getElementById('my_assets_description_div').style.display = "none";
		
		document.getElementById('my_assets_asset_img').src = '';
	}
}  


function toggleMyAssets(){
	if (!isWeb3Connected()){
		toggleWeb3Connect();
		return;
	}

	if (document.getElementById('my_assets').style.display == 'none'){
		document.getElementById('my_assets').style.display='block';
		refreshAssetsList();
	}
	else { 
		document.getElementById('my_assets').style.display='none';
		document.getElementById('my_assets_transfer_panel').style.display = "none";
		document.getElementById('my_assets_name_div').style.display = "none";
		document.getElementById('my_assets_description_div').style.display = "none";
		
		document.getElementById('assets_list').selectedIndex = 0;
		
		document.getElementById('my_assets_asset_img').src = '';
		
		resetMsg();
	}
}



function toggleFullImage(asset_id){
	if (document.getElementById('nft_full_image').style.display == 'none'){
	
		let assets = document.getElementById('NFT_profiles_list_cust');
		for (let i=1; i < assets.length; i++){
			let val = JSON.parse(assets[i].value);
			if (val.asset_id == asset_id){
				let full_img_url = val['asset_img_url'].replace('.png', '_full.png');
				if (imageExists(full_img_url)){
					document.getElementById('nft_full_image').style.display='block';
					document.getElementById('nft_full_image_img').src = full_img_url;
				}
			}
		}
			
	}
	else { 
		document.getElementById('nft_full_image').style.display='none';
	}
}

function imageExists(image_url){
	let http =  new XMLHttpRequest();
	http.open('HEAD', image_url, false);
	http.send();
	
	return http.status != 422;
}

async function showNFTDetails(hash){
	let owner = await window.nft_smartcontract.methods.tokenOwnerByHash(hash).call();
	let t_id =  await window.nft_smartcontract.methods.tokenIdByHash(hash).call();
	document.getElementById('nft_details_content').innerHTML = 'Owner: '+owner+'<BR>'+
	'Token ID: '+t_id;

	document.getElementById('nft_detail_img').src = NFT_ROOT_URL+'/'+hash+'.png';

	document.getElementById('nft_details').style.display = "block";


}

function getProfileDetailsById(p_id){
	if (p_id == BAD_PROFILE_ID) return null;

	let profiles = document.getElementById('NFT_profiles_list_cust');
	
	for (j=1; j< profiles.length; j++){
		let val = JSON.parse(profiles[j].value);
		if (val["asset_id"] == p_id) return val;
	}
	
	return null;

}

function refreshAssetsList(){
	if (window.refresh_assets_request_time){
		if (Date.now() - window.refresh_assets_request_time < 10000) return; //10 seconds
	}
		
	window.refresh_assets_request_time = Date.now();
	
	checkWallet(window.account,async (assets) => {
		
			document.getElementById('intro_assets').style.display = "block";
			let option;
			list_elem = document.getElementById('assets_list');
			while(list_elem.length>0){
	  			list_elem.remove(0);
	  		}
			setupList(list_elem, 'Choose asset');

			if (assets.length == 0){
				document.getElementById('intro_assets').innerHTML = 'Currently you have no assets';
			}
			else {
				document.getElementById('intro_assets').innerHTML = 'Loading assets..';
				for (let i=0; i < assets.length; i++){
					option = document.createElement('option');
					option.text = assets[i];

					let hash = await window.nft_smartcontract.methods.tokenHashById(assets[i]).call();
					let img_url = NFT_ROOT_URL+'/'+hash+'.png';

					const data = await getData(NFT_ROOT_URL+'/'+hash+'.json');


					option.value = JSON.stringify({token_id:assets[i], asset_name:data.name, asset_description: data.description, asset_img_url:img_url});
					
					
					
					option.text = 'FileRights: '+data.name+' [token id: '+option.text+']';
					
					
					list_elem.add(option);
				}
				list_elem.style.display = "block";
				document.getElementById('intro_assets').style.display = "none";
			}
			
			

		}); 

}

function checkWallet(wallet_address, callback = null){
	

	initNFTPubContract((nftpubContractInstance) => {
							  

				
			nftpubContractInstance.methods.balanceOf(wallet_address).call()
		    .then(async function(result) {
		        //console.log('total supply=',JSON.stringify(result));
		        let wallet_assets_total = result;
		        let assets_text = 'collectibles IDs: ';
		        let assets_arr = new Array();
		        let counter = 0;
				
				//console.log('wallet_assets_total=',wallet_assets_total);
		        if (wallet_assets_total == 0){
				  	safeSetInnerHTMLById('chw_NFT_info', "total collectibles: 0");
					if (callback) callback(assets_arr);
					return;
		         
		        } else {

		            for (let i=0; i < wallet_assets_total; i++){
		              nftpubContractInstance.methods.tokenOfOwnerByIndex(wallet_address,i).call() 
		                .then(async function(result) {
						  //console.log('asset id=',result);
		                  assets_text += result.toString()+'; ';
		                  assets_arr.push(result);
		                  counter++;
						  //console.log('counter=',counter);
		                  if (counter == wallet_assets_total){ //trick due to async
		                        safeSetInnerHTMLById('chw_NFT_info', "total collectibles: "+ wallet_assets_total.toString()+'<br>'+assets_text);
								if (callback) callback(assets_arr);
								return;
		                  }
		                })
		                .catch ( (err) => {
		                  safeSetInnerHTMLById('chw_NFT_info','smartcontract API error');
						  return;
		                });

		            }
		        }
				
			});

    
	});

}


function transferToWallet(to_wallet, token_id, callback = null){
	
	if (!isWeb3Connected()){
		toggleWeb3Connect();
		return;
	}
	
	if (!to_wallet || to_wallet == ''){
		infoMsg('please input wallet address');
		return;
	} 
	
	if (!token_id  || token_id == -1){
		infoMsg('please select token');
		return;
	} 
	temporaryDisableCurrentButton();

	try {

		initNFTPubContract((nftpubContractInstance) => {
								  
		    window.web3js.eth.getAccounts(function(error, accounts) {
		      if (error) throw error;
				try {		
				nftpubContractInstance.methods
					.safeTransferFrom(window.account, to_wallet, token_id) 
					.send( {from: accounts[0]}, function(error, txnHash) {
			        	if (error) throw error;
			        	output_transaction(txnHash);
						
			        	if (callback) callback();
			     	 })
					 .catch(error => 	{
							errorMsg('smartcontract communication error, try again');
						});   
				} catch (err) {
					errorMsg('smartcontract communication error, try again');
				}
			});
	    
		});
	} catch (err){
		errorMsg('smartcontract communication error, try again');
	}
}




if (window.location.pathname == '/'){
	document.getElementById('nft_full_info_close_button').addEventListener('click', () => {
		document.getElementById('nft_full_info').style.display = "none";
	});

	document.getElementById('my_assets_close_button').addEventListener('click', () => {
		toggleMyAssets();
	});


	document.getElementById('nft_full_image_close_button').addEventListener('click', () => {
		document.getElementById('nft_full_image').style.display = "none";
	});
}




//current wallet
function buyNFTByID(nft_id){

	if (!isWeb3Connected()){
		toggleWeb3Connect();
		return;
	}

	let elem = event.srcElement;
	elem.disabled = true;
	setTimeout(() => { elem.disabled  = false;}, 10000);
	buyNFT(nft_id,window.account);
}






async function getProfileSmartcontractDetails(getProfileIdCallback, callback = null){
  
   	let profile_id = getProfileIdCallback();
  	initMarketplaceContractReader((marketplaceContractInstance) => {
	      
	      marketplaceContractInstance.methods.viewNFTProfileDetails(profile_id).call()
	          .then(async (result) => {
				 
	             if (callback) callback(result); 
				
	          })
	          .catch((error) => {
	                
	              if (callback)  callback(null);
	          });
	  
	});
}

function infoMsg(msg){
	safeSetInnerHTMLById('info_pane',msg);
	document.getElementById('info_pane').classList.remove('info_pane_error');
	document.getElementById('info_pane').classList.add('info_pane_info');
}

function errorMsg(msg){
	safeSetInnerHTMLById('info_pane',msg);
	document.getElementById('info_pane').classList.add('info_pane_error');
	document.getElementById('info_pane').classList.remove('info_pane_info');
}

function resetMsg(){
	document.getElementById('info_pane').classList.remove('info_pane_error');
	safeSetInnerHTMLById('info_pane','');
}




function eventFire(el, etype){
  if (el.fireEvent) {
    el.fireEvent('on' + etype);
  } else {
    let evObj = document.createEvent('Events');
    evObj.initEvent(etype, true, false);
    el.dispatchEvent(evObj);
  }
}


async function onUniversalConnect() {
 	
	  
	
	  try {
	    window.provider = await web3Modal.connect();
		getAccountWalletConnect();
	  } catch(e) {
	    //console.log("Could not get a wallet connection", e);
	    return;
	  }

	  window.provider.on("accountsChanged", (accounts) => {
	    getAccountWalletConnect();
	  });

	  // Subscribe to chainId change
	  window.provider.on("chainChanged", (chainId) => {
	    getAccountWalletConnect();
	  });

	  // Subscribe to networkId change
	  window.provider.on("networkChanged", (networkId) => {
	    getAccountWalletConnect();
	  });

}

async function initNFTPubContract(callback = null){

    if (!window.nft_smartcontract){

            if (window.web3js){
                    window.nft_smartcontract = await new window.web3js.eth.Contract(nft_contract_abi, nft_contract_address);
                    if (callback) callback(window.nft_smartcontract);
            }

    } else {
            if (callback) callback(window.nft_smartcontract);
    } 
}

async function initNFTPubContractReader(callback = null){

    if (!window.nft_smartcontract_reader){

            if (window.web3js_reader){
                    window.nft_smartcontract_reader = await new window.web3js_reader.eth.Contract(nft_contract_abi, nft_contract_address);
                    if (callback) callback(window.nft_smartcontract_reader);
            }

    } else {
            if (callback) callback(window.nft_smartcontract_reader);
    } 
}

async function initWeb3jsReader(callback=null){
	
	if (!window.web3js_reader){
		window.web3js_reader = await new Web3(new Web3.providers.HttpProvider(infura_urls[current_network]));
	}	
	//and in any case
	if (callback) callback(window.web3js_reader); 

}


function isWeb3Connected(){
	
	if (isMetaMaskInstalled()){
		 return true
	}
	else{ 
		return !!window.provider;
	}
	
}


async function connectWeb3(){
	if (isMetaMaskInstalled()){
			//console.log('metamask installed');
			window.ethereum.autoRefreshOnNetworkChange = false;
			getAccount();

			
		 	window.ethereum.on('accountsChanged', function(accounts){
		  		getAccount();
		  	});

		  	window.ethereum.on('chainChanged', (chainId) => {
		 		getAccount();
			});

			

	} else {

		//try to connect with something built-in, like Opera
		try{
			await window.web3.currentProvider.enable();
			if (window.web3.currentProvider.isConnected()){
				window.provider =  window.web3.currentProvider;
				getAccountWalletConnect();
				return;
			}

		} catch {
			//do nothing
		}

		initWeb3Modal();

	 	//await web3Modal.updateTheme("dark");


	  	await onUniversalConnect();

	}

}


async function onUniversalDisconnect() {
	

  // TODO: Which providers have close method?
  if(window.provider.close) {
    await window.provider.close();

    // If the cached provider is not cleared,
    // WalletConnect will default to the existing session
    // and does not allow to re-scan the QR code with a new wallet.
    // Depending on your use case you may want or want not his behavir.
    await web3Modal.clearCachedProvider();
    window.provider = null;
	
  }

  window.account = null;
 
  window.location.reload();	
}

async function toggleWeb3Connect(){
	if (isMetaMaskInstalled()) return; //do nothing, we just use metamask


	
	if (!isWeb3Connected()){ 	//connect to mobile wallet
		await connectWeb3();
		if (isWeb3Connected()){ 
			walletButton.classList.remove('web3-disconnected');
			walletButton.classList.add('web3-connected');
		}

		return;
	} else {		//disconnect from mobile wallet
		await onUniversalDisconnect();
		if (!isWeb3Connected()){ 
			walletButton.classList.remove('web3-connected');
			walletButton.classList.add('web3-disconnected');
		}
		
		return;
	}
}

async function getData(url) {
  const response = await fetch(url);

  return response.json();
}

